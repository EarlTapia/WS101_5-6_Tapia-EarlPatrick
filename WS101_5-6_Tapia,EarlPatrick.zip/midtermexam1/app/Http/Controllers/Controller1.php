<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\transaction;
use App\Model\dashboard;
use Illuminate\Http\Support\Facades\DB;

class Controller1 extends Controller
{
    function userlogin()
    {
        return view('login');
    }
    function indexsingup()
    {
        return view('signup');
    }
    function indexdashboard()
    {
        return view('dashboard');
    }
    function indextransaction()
    {
        return view('transaction');
    }
}
