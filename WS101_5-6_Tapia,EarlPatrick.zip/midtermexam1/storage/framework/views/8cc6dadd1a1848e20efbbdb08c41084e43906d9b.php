<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color:grey; align-self: center;">
    <form action="signup" method=POST>
        <center>
        <?php echo csrf_field(); ?>
        <h1>SIGNUP</h1>
        <table>
        <input type="text" placeholder="Enter your id number"><br><br>
        <input type="text" placeholder="Enter your name"><br><br>
        <input type="password" placeholder="Enter your password"><br><br>
        </table>
        <button type="submit">Confirm</button>
        </center>
    </form>
</body>
</html><?php /**PATH C:\xampp\Xampp\htdocs\midtermexam1\resources\views/signup.blade.php ENDPATH**/ ?>