<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color:grey; align-self: center;">
<form action="login" method=POST>
        <center>
        <?php echo csrf_field(); ?>
        <h1>LOGIN</h1>
        <input type="text" placeholder="Enter your username"><br><br>
        <input type="password" placeholder="Enter your password"><br><br>
        <button type="submit">login</button>
        </center>
    </form>
</body>
</html><?php /**PATH C:\xampp\Xampp\htdocs\midtermexam1\resources\views/login.blade.php ENDPATH**/ ?>