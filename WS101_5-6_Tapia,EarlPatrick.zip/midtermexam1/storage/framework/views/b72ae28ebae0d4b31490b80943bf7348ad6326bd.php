<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color:grey; align-self: center;">
    <?php echo csrf_field(); ?>
    <center>
    <h1>DASHBOARD</h1>
    <nav>
    <a href="<?php echo e(url('dashboard')); ?>">Dashboard</a>
    <a href="<?php echo e(url('transaction')); ?>">Transaction</a>
    </nav>
    </center>
    <center>
        <br><br><br>
        <h1>Name: Earl Patrick Tapia</h1>
        <h1>ID number: 59821775</h1>
        <h1>amount: 3,000 php</h1>
    </center>
</body>
</html><?php /**PATH C:\xampp\Xampp\htdocs\midtermexam1\resources\views/dashboard.blade.php ENDPATH**/ ?>